#!/usr/bin/env python
# coding: utf-8

# In[22]:


from litellm import completion
import os
import json
import re

from pathlib import Path

from Bio import Entrez
from Bio import Medline

Entrez.email = "rittalmehta@gmail.com"

MODEL_NAME = "openai/gpt-4.1-mini"

PROVIDER_FILE = Path("providers_enriched.json")


# In[3]:


os.environ["OPENAI_API_KEY"] = "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"


# In[4]:


def ask_agent(system_prompt, user_prompt):

    response = completion(
        model="openai/gpt-4.1-mini",
        messages=[
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ],
        temperature=0.2
    )

    return response.choices[0].message.content


# In[6]:


def education_agent(question,
                    diagnosis,
                    evidence):

    system_prompt = f"""
You are a pediatric congenital heart disease educator.

Your role is to provide evidence-based educational information.

Rules:

- Never diagnose.
- Never replace a cardiologist.
- Explain concepts in family-friendly language.
- Mention uncertainty when evidence is limited.
- Recommend discussing important decisions with the congenital heart team.

Always produce this format:

# Educational Summary

## What this means

## Key Points

## Evidence Summary

## Questions to discuss with your cardiologist
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[8]:


def exercise_agent(question,
                   diagnosis,
                   activity,
                   risk,
                   evidence):

    system_prompt = """
You are a Pediatric Cardiac Rehabilitation and Exercise Specialist.

Your role is to educate families about physical activity and exercise in congenital heart disease.

Rules:

- Never decide sports eligibility.
- Never replace the treating cardiologist.
- Use evidence when available.
- Highlight warning symptoms requiring medical attention.
- Encourage individualized exercise recommendations.

Always return exactly these sections:

# Exercise Summary

## Safety Review

## Exercise Considerations

## Evidence Summary

## Questions for the Cardiologist

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Activity:
{activity}

Risk:
{risk}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(system_prompt, user_prompt)


# In[10]:


def nutrition_agent(question,
                    diagnosis,
                    evidence):

    system_prompt = """
You are a Pediatric Congenital Heart Disease Nutrition Specialist.

Your role is to educate families about:

• Nutrition
• Growth
• Feeding
• Weight gain
• Appetite
• Dietitian referral

Rules:

- Never prescribe treatment.
- Never replace the treating cardiologist or dietitian.
- Use the provided evidence.
- Explain concepts in family-friendly language.

Always return:

# Nutrition Summary

## Growth Review

## Nutrition Considerations

## Evidence Summary

## Questions for the Cardiologist or Dietitian

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[12]:


def surgery_agent(question,
                  diagnosis,
                  evidence):

    system_prompt = """
You are a Pediatric Congenital Cardiac Surgery Education Specialist.

Your role is to educate families about congenital heart surgery.

Rules:

- Never recommend surgery.
- Never decide whether surgery is necessary.
- Explain concepts using family-friendly language.
- Encourage discussion with the congenital cardiac surgeon.
- Use the supplied evidence.

Always return:

# Surgical Summary

## Surgical Considerations

## Evidence Summary

## Questions for the Cardiac Surgeon

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[14]:


def caregiver_agent(question,
                    diagnosis,
                    evidence):

    system_prompt = """
You are a Caregiver Support and Family Navigation Agent for congenital heart disease.

Your role is to support parents and caregivers with practical, educational,
and care-navigation guidance.

You may help with:

- Caregiver stress and feeling overwhelmed
- Preparing for clinic visits or surgery
- Communicating with the child's healthcare team
- School and family coordination
- Talking with siblings
- Identifying appropriate hospital support services
- Questions to ask social work, psychology, child life, or the cardiology team

Rules:

- Do not diagnose or treat mental health conditions.
- Do not provide psychotherapy.
- Do not replace the child's medical team.
- Do not minimize caregiver concerns.
- Use the supplied evidence when relevant.
- Recommend urgent help when the caregiver describes immediate danger,
  inability to keep themselves or the child safe, or a medical emergency.
- Use supportive, respectful, family-friendly language.

Always return exactly these sections:

# Caregiver Support Summary

## Current Caregiving Concerns

## Practical Next Steps

## Preparing to Speak With the Care Team

## Support Services That May Help

## Evidence Summary

## When to Seek Urgent Help

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Caregiver Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[16]:


def qol_agent(question,
              diagnosis,
              evidence):

    system_prompt = """
You are a Pediatric Congenital Heart Disease Quality of Life Agent.

Your role is to support families with educational guidance about:

- School participation
- Anxiety and emotional well-being
- Friendships and social activities
- Confidence and body image
- Fatigue and daily functioning
- Coping with congenital heart disease
- School accommodations
- Family communication

Rules:

- Do not diagnose a mental health condition.
- Do not provide psychotherapy.
- Do not replace a psychologist, social worker, school counselor, or cardiologist.
- Use supportive and family-friendly language.
- Use the supplied evidence when relevant.
- Encourage professional support when concerns are persistent, worsening, or affecting daily life.
- Recommend urgent help if the question describes immediate danger or inability to stay safe.

Always return exactly these sections:

# Quality of Life Summary

## Current Concerns

## School and Daily Life

## Emotional and Social Well-being

## Practical Support Strategies

## Questions for the Care Team

## Evidence Summary

## When to Seek Additional Help

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[18]:


def identify_diagnosis(question):

    text = question.lower()

    diagnoses = {
        "Tetralogy of Fallot": [
            "tetralogy of fallot",
            "tof"
        ],
        "Fontan Circulation": [
            "fontan",
            "single ventricle"
        ],
        "Hypoplastic Left Heart Syndrome": [
            "hlhs",
            "hypoplastic left heart syndrome"
        ],
        "Transposition of the Great Arteries": [
            "transposition of the great arteries",
            "tga",
            "arterial switch"
        ],
        "Atrioventricular Septal Defect": [
            "atrioventricular septal defect",
            "avsd",
            "av canal",
            "complete canal"
        ],
        "Ventricular Septal Defect": [
            "ventricular septal defect",
            "vsd"
        ],
        "Atrial Septal Defect": [
            "atrial septal defect",
            "asd"
        ],
        "Coarctation of the Aorta": [
            "coarctation of the aorta",
            "coarctation",
            "coa"
        ],
        "Ebstein Anomaly": [
            "ebstein anomaly",
            "ebstein"
        ],
        "Norwood Palliation": [
            "norwood"
        ],
        "Congenital Heart Disease": [
            "congenital heart disease",
            "chd"
        ]
    }

    for diagnosis, keywords in diagnoses.items():
        if any(keyword in text for keyword in keywords):
            return diagnosis

    return "Unknown"


def identify_activity(question):

    text = question.lower()

    activities = {
        "Soccer": ["soccer", "football"],
        "Swimming": ["swimming", "swim"],
        "Basketball": ["basketball"],
        "Running": ["running", "run", "jogging"],
        "Cycling": ["cycling", "biking", "bike"],
        "Gym or Strength Training": [
            "gym",
            "weightlifting",
            "weight lifting",
            "weights",
            "strength training"
        ],
        "Dance": ["dance", "dancing"],
        "Physical Education": [
            "physical education",
            "pe class",
            "p.e."
        ],
        "Competitive Sports": [
            "competitive sports",
            "sports team"
        ]
    }

    for activity, keywords in activities.items():
        if any(keyword in text for keyword in keywords):
            return activity

    return "General Activity"


def identify_topic(question):

    text = question.lower()

    # Safety-critical symptoms should still route to the relevant clinical topic.
    if any(term in text for term in [
        "surgery",
        "operation",
        "reoperation",
        "surgeon",
        "surgical",
        "procedure",
        "valve replacement"
    ]):
        return "surgery"

    if any(term in text for term in [
        "nutrition",
        "diet",
        "food",
        "feeding",
        "appetite",
        "weight gain",
        "poor weight",
        "growth",
        "calories",
        "protein",
        "tube feeding"
    ]):
        return "nutrition"

    if any(term in text for term in [
        "exercise",
        "sport",
        "soccer",
        "football",
        "basketball",
        "swimming",
        "running",
        "cycling",
        "gym",
        "rehabilitation",
        "rehab",
        "physical activity",
        "pe class"
    ]):
        return "exercise"

    if any(term in text for term in [
        "caregiver",
        "as a parent",
        "as a mother",
        "as a father",
        "i am overwhelmed",
        "i'm overwhelmed",
        "burnout",
        "exhausted caring",
        "family support",
        "sibling",
        "prepare for clinic",
        "prepare for surgery",
        "care coordination"
    ]):
        return "caregiver"

    if any(term in text for term in [
        "school",
        "sad",
        "upset",
        "anxiety",
        "anxious",
        "depressed",
        "quality of life",
        "friend",
        "confidence",
        "bully",
        "embarrassed",
        "mental health",
        "feels different",
        "social"
    ]):
        return "qol"

    return "education"


def identify_risk(question):

    text = question.lower()

    high_risk_terms = [
        "chest pain",
        "fainting",
        "fainted",
        "syncope",
        "passed out",
        "palpitations",
        "arrhythmia",
        "blue lips",
        "cyanosis",
        "difficulty breathing",
        "shortness of breath at rest",
        "cardiac arrest",
        "cannot breathe"
    ]

    moderate_risk_terms = [
        "dizziness",
        "fatigue",
        "very tired",
        "exercise intolerance",
        "poor exercise tolerance",
        "shortness of breath with exercise"
    ]

    if any(term in text for term in high_risk_terms):
        return "HIGH"

    if any(term in text for term in moderate_risk_terms):
        return "MODERATE"

    return "LOW"


# In[19]:


TOPIC_SEARCH_TERMS = {
    "exercise": (
        "exercise OR physical activity OR sports "
        "OR cardiac rehabilitation OR exercise training"
    ),
    "nutrition": (
        "nutrition OR feeding OR growth OR weight gain "
        "OR malnutrition OR diet"
    ),
    "surgery": (
        "surgery OR cardiac surgery OR reoperation "
        "OR surgical outcomes"
    ),
    "qol": (
        "quality of life OR psychosocial OR school "
        "OR anxiety OR mental health"
    ),
    "caregiver": (
        "caregiver OR parent stress OR family support "
        "OR caregiver burden OR psychosocial support"
    ),
    "education": (
        "patient education OR family education "
        "OR long-term follow-up"
    )
}


def search_pubmed(query, max_results=3):

    handle = Entrez.esearch(
        db="pubmed",
        term=query,
        retmax=max_results,
        sort="relevance"
    )

    results = Entrez.read(handle)
    handle.close()

    return results.get("IdList", [])


def fetch_articles(id_list):

    if not id_list:
        return []

    handle = Entrez.efetch(
        db="pubmed",
        id=",".join(id_list),
        rettype="medline",
        retmode="text"
    )

    records = list(Medline.parse(handle))
    handle.close()

    return records


class EvidenceAgent:

    def __init__(self):
        self.cache = {}

    def search(self, diagnosis, topic):

        condition = (
            diagnosis
            if diagnosis != "Unknown"
            else "congenital heart disease"
        )

        topic_terms = TOPIC_SEARCH_TERMS.get(
            topic,
            TOPIC_SEARCH_TERMS["education"]
        )

        query = f'"{condition}" AND ({topic_terms})'

        if query in self.cache:
            return self.cache[query]

        pmids = search_pubmed(
            query=query,
            max_results=3
        )

        articles = fetch_articles(pmids)

        self.cache[query] = articles

        return articles


evidence_agent = EvidenceAgent()


def summarize_evidence(articles):

    if not articles:
        return (
            "No directly relevant PubMed records were retrieved. "
            "The response should acknowledge the limited evidence."
        )

    summaries = []

    for article in articles:

        pmid = article.get("PMID", "Not available")
        title = article.get("TI", "Title unavailable")
        abstract = article.get("AB", "")

        short_abstract = re.sub(
            r"\s+",
            " ",
            abstract
        ).strip()[:600]

        if not short_abstract:
            short_abstract = "Abstract unavailable."

        summaries.append(
            f"""
PMID: {pmid}

Title: {title}

Abstract excerpt:
{short_abstract}
""".strip()
        )

    return "\n\n---\n\n".join(summaries)


# In[23]:


def load_provider_database(
    filename=PROVIDER_FILE
):

    path = Path(filename)

    if not path.exists():
        return []

    with path.open(
        "r",
        encoding="utf-8"
    ) as file:
        data = json.load(file)

    # Supports either:
    # 1. A direct list of providers
    # 2. A dictionary containing a "providers" list
    if isinstance(data, list):
        providers = data

    elif isinstance(data, dict):
        providers = data.get("providers", [])

    else:
        providers = []

    normalized = []

    for provider in providers:

        provider_copy = provider.copy()

        combined_text = " ".join([
            str(provider_copy.get("name", "")),
            str(provider_copy.get("hospital", "")),
            str(provider_copy.get("department", "")),
            str(provider_copy.get("specialty", "")),
            str(provider_copy.get("titles", "")),
            str(provider_copy.get("biography", "")),
            str(provider_copy.get("departments_text", "")),
            str(provider_copy.get("matching_text", "")),
            " ".join(provider_copy.get("roles", []))
            if isinstance(provider_copy.get("roles"), list)
            else str(provider_copy.get("roles", ""))
        ])

        provider_copy["searchable_text"] = (
            combined_text.lower()
        )

        normalized.append(provider_copy)

    return normalized


PROVIDER_DATABASE = load_provider_database()


# In[24]:


TOPIC_PROVIDER_KEYWORDS = {
    "exercise": [
        "exercise",
        "rehabilitation",
        "cardiac rehabilitation",
        "exercise physiology",
        "sports",
        "fitness",
        "cardiopulmonary exercise",
        "cardiology"
    ],
    "nutrition": [
        "nutrition",
        "dietitian",
        "diet",
        "feeding",
        "growth",
        "gastroenterology"
    ],
    "surgery": [
        "cardiac surgery",
        "cardiothoracic surgery",
        "congenital cardiac surgery",
        "surgeon",
        "surgery"
    ],
    "qol": [
        "psychology",
        "behavioral health",
        "neurodevelopment",
        "social work",
        "quality of life",
        "mental health"
    ],
    "caregiver": [
        "social work",
        "psychology",
        "behavioral health",
        "child life",
        "family support",
        "care coordination",
        "nursing"
    ],
    "education": [
        "congenital cardiology",
        "cardiology",
        "pediatric cardiology"
    ]
}


def diagnosis_keywords(diagnosis):

    mapping = {
        "Tetralogy of Fallot": [
            "tetralogy of fallot",
            "tof"
        ],
        "Fontan Circulation": [
            "fontan",
            "single ventricle"
        ],
        "Hypoplastic Left Heart Syndrome": [
            "hlhs",
            "hypoplastic left heart",
            "single ventricle"
        ],
        "Transposition of the Great Arteries": [
            "transposition",
            "tga",
            "arterial switch"
        ],
        "Atrioventricular Septal Defect": [
            "atrioventricular septal defect",
            "avsd",
            "av canal"
        ],
        "Coarctation of the Aorta": [
            "coarctation"
        ],
        "Ebstein Anomaly": [
            "ebstein"
        ]
    }

    return mapping.get(
        diagnosis,
        [diagnosis.lower()]
        if diagnosis != "Unknown"
        else []
    )


def recommend_providers(
    question,
    diagnosis,
    topic,
    hospital="Childrens National",
    top_n=3
):

    if not PROVIDER_DATABASE:
        return []

    topic_terms = TOPIC_PROVIDER_KEYWORDS.get(
        topic,
        []
    )

    condition_terms = diagnosis_keywords(
        diagnosis
    )

    question_words = {
        word
        for word in re.findall(
            r"[a-zA-Z]{5,}",
            question.lower()
        )
        if word not in {
            "about",
            "child",
            "daughter",
            "family",
            "should",
            "would",
            "could",
            "their",
            "there",
            "which"
        }
    }

    matches = []

    for provider in PROVIDER_DATABASE:

        provider_hospital = provider.get(
            "hospital",
            ""
        )

        if (
            hospital
            and provider_hospital
            and provider_hospital.lower()
            != hospital.lower()
        ):
            continue

        text = provider.get(
            "searchable_text",
            ""
        )

        score = 0
        reasons = []

        topic_hits = [
            term
            for term in topic_terms
            if term in text
        ]

        if topic_hits:
            score += min(
                50,
                15 + (10 * len(topic_hits))
            )

            reasons.append(
                "Profile matches the "
                f"{topic.replace('_', ' ')} care topic"
            )

        diagnosis_hits = [
            term
            for term in condition_terms
            if term in text
        ]

        if diagnosis_hits:
            score += min(
                35,
                20 + (5 * len(diagnosis_hits))
            )

            reasons.append(
                f"Profile mentions expertise relevant to {diagnosis}"
            )

        department = provider.get(
            "department",
            ""
        ).lower()

        if (
            topic == "surgery"
            and "surgery" in department
        ):
            score += 30
            reasons.append(
                "Member of the cardiac surgery department"
            )

        elif (
            topic in ["exercise", "education"]
            and "cardiology" in department
        ):
            score += 15
            reasons.append(
                "Member of the cardiology department"
            )

        shared_words = [
            word
            for word in question_words
            if word in text
        ]

        if shared_words:
            score += min(
                20,
                4 * len(shared_words)
            )

            reasons.append(
                "Provider profile shares relevant terms "
                "with the family question"
            )

        if provider.get("research_profile_url"):
            score += 3

        if score > 0:
            matches.append({
                "provider": provider,
                "score": score,
                "reasons": list(dict.fromkeys(reasons))
            })

    matches.sort(
        key=lambda item: (
            item["score"],
            item["provider"].get("name", "")
        ),
        reverse=True
    )

    return matches[:top_n]


def format_provider_matches(matches):

    if not matches:
        return """
No expertise-matched provider was identified from the current local
provider database. Please contact the congenital heart program for
appropriate care navigation.
""".strip()

    sections = []

    for index, match in enumerate(
        matches,
        start=1
    ):

        provider = match["provider"]
        reasons = match["reasons"]

        name = provider.get(
            "name",
            "Provider name unavailable"
        )

        specialty = (
            provider.get("specialty")
            or provider.get("department")
            or "Specialty not listed"
        )

        profile_url = provider.get(
            "profile_url",
            ""
        )

        reason_text = "\n".join(
            f"- {reason}"
            for reason in reasons
        )

        section = f"""
### {index}. {name}

**Specialty/Department:** {specialty}

**Prototype Match Score:** {match['score']}

**Why this provider matched:**

{reason_text}
""".strip()

        if profile_url:
            section += (
                f"\n\n**Official profile:** {profile_url}"
            )

        sections.append(section)

    return "\n\n---\n\n".join(sections)


# In[25]:


AGENT_NAMES = {
    "exercise": (
        "Cardiac Exercise and Rehabilitation Agent"
    ),
    "nutrition": (
        "Nutrition and Growth Agent"
    ),
    "surgery": (
        "Congenital Cardiac Surgery Education Agent"
    ),
    "qol": (
        "Quality-of-Life Agent"
    ),
    "caregiver": (
        "Caregiver Support and Family Navigation Agent"
    ),
    "education": (
        "Congenital Heart Disease Education Agent"
    )
}


def chief_agent(
    question,
    hospital="Childrens National"
):

    if not question or not question.strip():
        raise ValueError(
            "Please enter a family question."
        )

    diagnosis = identify_diagnosis(question)
    activity = identify_activity(question)
    topic = identify_topic(question)
    risk = identify_risk(question)

    articles = evidence_agent.search(
        diagnosis=diagnosis,
        topic=topic
    )

    evidence = summarize_evidence(
        articles
    )

    if topic == "exercise":

        report = exercise_agent(
            question=question,
            diagnosis=diagnosis,
            activity=activity,
            risk=risk,
            evidence=evidence
        )

    elif topic == "nutrition":

        report = nutrition_agent(
            question=question,
            diagnosis=diagnosis,
            evidence=evidence
        )

    elif topic == "surgery":

        report = surgery_agent(
            question=question,
            diagnosis=diagnosis,
            evidence=evidence
        )

    elif topic == "qol":

        report = qol_agent(
            question=question,
            diagnosis=diagnosis,
            evidence=evidence
        )

    elif topic == "caregiver":

        report = caregiver_agent(
            question=question,
            diagnosis=diagnosis,
            evidence=evidence
        )

    else:

        report = education_agent(
            question=question,
            diagnosis=diagnosis,
            evidence=evidence
        )

    provider_matches = recommend_providers(
        question=question,
        diagnosis=diagnosis,
        topic=topic,
        hospital=hospital,
        top_n=3
    )

    provider_report = format_provider_matches(
        provider_matches
    )

    metadata = f"""
# CHD Family Copilot Assessment

**Detected diagnosis:** {diagnosis}

**Detected topic:** {topic.title()}

**Detected activity:** {activity}

**Risk flag:** {risk}

**Selected agent:** {AGENT_NAMES[topic]}

**Hospital directory:** {hospital}
""".strip()

    final_report = f"""
{metadata}

---

{report}

---

# Expertise-Matched Specialists

The following results represent prototype expertise matching based on
publicly available hospital-profile information. They do not rank
physician quality and do not replace formal referral or triage.

{provider_report}

---

# Important Safety Notice

This prototype provides educational and care-navigation support only.
It does not diagnose, prescribe treatment, provide sports clearance,
determine whether surgery is needed, or replace the treating congenital
heart team.

For severe symptoms, fainting, significant breathing difficulty,
persistent chest pain, blue coloration, or another medical emergency,
seek immediate medical care.
""".strip()

    return final_report


# In[ ]:




