#!/usr/bin/env python
# coding: utf-8

# In[22]:


from litellm import completion
import os
import json
import re

from pathlib import Path
from datetime import datetime

from Bio import Entrez
from Bio import Medline

Entrez.email = "rittalmehta@gmail.com"

MODEL_NAME = "openai/gpt-4.1-mini"

PROVIDER_FILE = Path("providers_enriched.json")



# In[4]:


def ask_agent(system_prompt, user_prompt):

    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY is not configured. Set it in the environment "
            "before starting the app."
        )

    response = completion(
        model=MODEL_NAME,
        messages=[
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ],
        temperature=0.2
    )

    return response.choices[0].message.content


# In[6]:


def education_agent(question,
                    diagnosis,
                    evidence):

    system_prompt = f"""
You are a pediatric congenital heart disease educator.

Your role is to provide evidence-based educational information.

Rules:

- Never diagnose.
- Never replace a cardiologist.
- Explain concepts in family-friendly language.
- Mention uncertainty when evidence is limited.
- Recommend discussing important decisions with the congenital heart team.

Always produce this format:

# Educational Summary

## What this means

## Key Points

## Evidence Summary

## Questions to discuss with your cardiologist
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[8]:


def exercise_agent(question,
                   diagnosis,
                   activity,
                   risk,
                   evidence):

    system_prompt = """
You are a Pediatric Cardiac Rehabilitation and Exercise Specialist.

Your role is to educate families about physical activity and exercise in congenital heart disease.

Rules:

- Never decide sports eligibility.
- Never replace the treating cardiologist.
- Use evidence when available.
- Highlight warning symptoms requiring medical attention.
- Encourage individualized exercise recommendations.

Always return exactly these sections:

# Exercise Summary

## Safety Review

## Exercise Considerations

## Evidence Summary

## Questions for the Cardiologist

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Activity:
{activity}

Risk:
{risk}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(system_prompt, user_prompt)


# In[10]:


def nutrition_agent(question,
                    diagnosis,
                    evidence):

    system_prompt = """
You are a Pediatric Congenital Heart Disease Nutrition Specialist.

Your role is to educate families about:

• Nutrition
• Growth
• Feeding
• Weight gain
• Appetite
• Dietitian referral

Rules:

- Never prescribe treatment.
- Never replace the treating cardiologist or dietitian.
- Use the provided evidence.
- Explain concepts in family-friendly language.

Always return:

# Nutrition Summary

## Growth Review

## Nutrition Considerations

## Evidence Summary

## Questions for the Cardiologist or Dietitian

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[12]:


def surgery_agent(question,
                  diagnosis,
                  evidence):

    system_prompt = """
You are a Pediatric Congenital Cardiac Surgery Education Specialist.

Your role is to educate families about congenital heart surgery.

Rules:

- Never recommend surgery.
- Never decide whether surgery is necessary.
- Explain concepts using family-friendly language.
- Encourage discussion with the congenital cardiac surgeon.
- Use the supplied evidence.

Always return:

# Surgical Summary

## Surgical Considerations

## Evidence Summary

## Questions for the Cardiac Surgeon

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[14]:


def caregiver_agent(question,
                    diagnosis,
                    evidence):

    system_prompt = """
You are a Caregiver Support and Family Navigation Agent for congenital heart disease.

Your role is to support parents and caregivers with practical, educational,
and care-navigation guidance.

You may help with:

- Caregiver stress and feeling overwhelmed
- Preparing for clinic visits or surgery
- Communicating with the child's healthcare team
- School and family coordination
- Talking with siblings
- Identifying appropriate hospital support services
- Questions to ask social work, psychology, child life, or the cardiology team

Rules:

- Do not diagnose or treat mental health conditions.
- Do not provide psychotherapy.
- Do not replace the child's medical team.
- Do not minimize caregiver concerns.
- Use the supplied evidence when relevant.
- Recommend urgent help when the caregiver describes immediate danger,
  inability to keep themselves or the child safe, or a medical emergency.
- Use supportive, respectful, family-friendly language.

Always return exactly these sections:

# Caregiver Support Summary

## Current Caregiving Concerns

## Practical Next Steps

## Preparing to Speak With the Care Team

## Support Services That May Help

## Evidence Summary

## When to Seek Urgent Help

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Caregiver Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[16]:


def qol_agent(question,
              diagnosis,
              evidence):

    system_prompt = """
You are a Pediatric Congenital Heart Disease Quality of Life Agent.

Your role is to support families with educational guidance about:

- School participation
- Anxiety and emotional well-being
- Friendships and social activities
- Confidence and body image
- Fatigue and daily functioning
- Coping with congenital heart disease
- School accommodations
- Family communication

Rules:

- Do not diagnose a mental health condition.
- Do not provide psychotherapy.
- Do not replace a psychologist, social worker, school counselor, or cardiologist.
- Use supportive and family-friendly language.
- Use the supplied evidence when relevant.
- Encourage professional support when concerns are persistent, worsening, or affecting daily life.
- Recommend urgent help if the question describes immediate danger or inability to stay safe.

Always return exactly these sections:

# Quality of Life Summary

## Current Concerns

## School and Daily Life

## Emotional and Social Well-being

## Practical Support Strategies

## Questions for the Care Team

## Evidence Summary

## When to Seek Additional Help

## Disclaimer
"""

    user_prompt = f"""
Diagnosis:
{diagnosis}

Evidence:
{evidence}

Question:
{question}
"""

    return ask_agent(
        system_prompt,
        user_prompt
    )


# In[18]:


def identify_diagnosis(question):

    text = question.lower()

    diagnoses = {
        "Tetralogy of Fallot": [
            "tetralogy of fallot",
            "tof"
        ],
        "Fontan Circulation": [
            "fontan",
            "single ventricle"
        ],
        "Hypoplastic Left Heart Syndrome": [
            "hlhs",
            "hypoplastic left heart syndrome"
        ],
        "Transposition of the Great Arteries": [
            "transposition of the great arteries",
            "tga",
            "arterial switch"
        ],
        "Atrioventricular Septal Defect": [
            "atrioventricular septal defect",
            "avsd",
            "av canal",
            "complete canal"
        ],
        "Ventricular Septal Defect": [
            "ventricular septal defect",
            "vsd"
        ],
        "Atrial Septal Defect": [
            "atrial septal defect",
            "asd"
        ],
        "Coarctation of the Aorta": [
            "coarctation of the aorta",
            "coarctation",
            "coa"
        ],
        "Ebstein Anomaly": [
            "ebstein anomaly",
            "ebstein"
        ],
        "Norwood Palliation": [
            "norwood"
        ],
        "Congenital Heart Disease": [
            "congenital heart disease",
            "chd"
        ]
    }

    for diagnosis, keywords in diagnoses.items():
        if any(keyword in text for keyword in keywords):
            return diagnosis

    return "Unknown"


def identify_activity(question):

    text = question.lower()

    activities = {
        "Soccer": ["soccer", "football"],
        "Swimming": ["swimming", "swim"],
        "Basketball": ["basketball"],
        "Running": ["running", "run", "jogging"],
        "Cycling": ["cycling", "biking", "bike"],
        "Gym or Strength Training": [
            "gym",
            "weightlifting",
            "weight lifting",
            "weights",
            "strength training"
        ],
        "Dance": ["dance", "dancing"],
        "Physical Education": [
            "physical education",
            "pe class",
            "p.e."
        ],
        "Competitive Sports": [
            "competitive sports",
            "sports team"
        ]
    }

    for activity, keywords in activities.items():
        if any(keyword in text for keyword in keywords):
            return activity

    return "General Activity"


def identify_topic(question):

    text = question.lower()

    # Safety-critical symptoms should still route to the relevant clinical topic.
    if any(term in text for term in [
        "surgery",
        "operation",
        "reoperation",
        "surgeon",
        "surgical",
        "procedure",
        "valve replacement"
    ]):
        return "surgery"

    if any(term in text for term in [
        "nutrition",
        "diet",
        "food",
        "feeding",
        "appetite",
        "weight gain",
        "poor weight",
        "growth",
        "calories",
        "protein",
        "tube feeding"
    ]):
        return "nutrition"

    if any(term in text for term in [
        "exercise",
        "sport",
        "soccer",
        "football",
        "basketball",
        "swimming",
        "running",
        "cycling",
        "gym",
        "rehabilitation",
        "rehab",
        "physical activity",
        "pe class"
    ]):
        return "exercise"

    if any(term in text for term in [
        "caregiver",
        "as a parent",
        "as a mother",
        "as a father",
        "i am overwhelmed",
        "i'm overwhelmed",
        "burnout",
        "exhausted caring",
        "family support",
        "sibling",
        "prepare for clinic",
        "prepare for surgery",
        "care coordination"
    ]):
        return "caregiver"

    if any(term in text for term in [
        "school",
        "sad",
        "upset",
        "anxiety",
        "anxious",
        "depressed",
        "quality of life",
        "friend",
        "confidence",
        "bully",
        "embarrassed",
        "mental health",
        "feels different",
        "social"
    ]):
        return "qol"

    return "education"


def identify_risk(question):

    text = question.lower()

    high_risk_terms = [
        "chest pain",
        "fainting",
        "fainted",
        "syncope",
        "passed out",
        "palpitations",
        "arrhythmia",
        "blue lips",
        "cyanosis",
        "difficulty breathing",
        "shortness of breath at rest",
        "cardiac arrest",
        "cannot breathe"
    ]

    moderate_risk_terms = [
        "dizziness",
        "fatigue",
        "very tired",
        "exercise intolerance",
        "poor exercise tolerance",
        "shortness of breath with exercise"
    ]

    if any(term in text for term in high_risk_terms):
        return "HIGH"

    if any(term in text for term in moderate_risk_terms):
        return "MODERATE"

    return "LOW"


# In[19]:


TOPIC_SEARCH_TERMS = {
    "exercise": (
        "exercise OR physical activity OR sports "
        "OR cardiac rehabilitation OR exercise training"
    ),
    "nutrition": (
        "nutrition OR feeding OR growth OR weight gain "
        "OR malnutrition OR diet"
    ),
    "surgery": (
        "surgery OR cardiac surgery OR reoperation "
        "OR surgical outcomes"
    ),
    "qol": (
        "quality of life OR psychosocial OR school "
        "OR anxiety OR mental health"
    ),
    "caregiver": (
        "caregiver OR parent stress OR family support "
        "OR caregiver burden OR psychosocial support"
    ),
    "education": (
        "patient education OR family education "
        "OR long-term follow-up"
    )
}


def search_pubmed(query, max_results=3):

    handle = Entrez.esearch(
        db="pubmed",
        term=query,
        retmax=max_results,
        sort="relevance"
    )

    results = Entrez.read(handle)
    handle.close()

    return results.get("IdList", [])


def fetch_articles(id_list):

    if not id_list:
        return []

    handle = Entrez.efetch(
        db="pubmed",
        id=",".join(id_list),
        rettype="medline",
        retmode="text"
    )

    records = list(Medline.parse(handle))
    handle.close()

    return records


class EvidenceAgent:

    def __init__(self):
        self.cache = {}

    def search(self, diagnosis, topic):

        condition = (
            diagnosis
            if diagnosis != "Unknown"
            else "congenital heart disease"
        )

        topic_terms = TOPIC_SEARCH_TERMS.get(
            topic,
            TOPIC_SEARCH_TERMS["education"]
        )

        query = f'"{condition}" AND ({topic_terms})'

        if query in self.cache:
            return self.cache[query]

        pmids = search_pubmed(
            query=query,
            max_results=3
        )

        articles = fetch_articles(pmids)

        self.cache[query] = articles

        return articles


evidence_agent = EvidenceAgent()


def summarize_evidence(articles):

    if not articles:
        return (
            "No directly relevant PubMed records were retrieved. "
            "The response should acknowledge the limited evidence."
        )

    summaries = []

    for article in articles:

        pmid = article.get("PMID", "Not available")
        title = article.get("TI", "Title unavailable")
        abstract = article.get("AB", "")

        short_abstract = re.sub(
            r"\s+",
            " ",
            abstract
        ).strip()[:600]

        if not short_abstract:
            short_abstract = "Abstract unavailable."

        summaries.append(
            f"""
PMID: {pmid}

Title: {title}

Abstract excerpt:
{short_abstract}
""".strip()
        )

    return "\n\n---\n\n".join(summaries)


# In[23]:


def load_provider_database(
    filename=PROVIDER_FILE
):

    path = Path(filename)

    if not path.exists():
        return []

    with path.open(
        "r",
        encoding="utf-8"
    ) as file:
        data = json.load(file)

    # Supports either:
    # 1. A direct list of providers
    # 2. A dictionary containing a "providers" list
    if isinstance(data, list):
        providers = data

    elif isinstance(data, dict):
        providers = data.get("providers", [])

    else:
        providers = []

    normalized = []

    for provider in providers:

        provider_copy = provider.copy()

        combined_text = " ".join([
            str(provider_copy.get("name", "")),
            str(provider_copy.get("hospital", "")),
            str(provider_copy.get("department", "")),
            str(provider_copy.get("specialty", "")),
            str(provider_copy.get("titles", "")),
            str(provider_copy.get("biography", "")),
            str(provider_copy.get("departments_text", "")),
            str(provider_copy.get("matching_text", "")),
            " ".join(provider_copy.get("roles", []))
            if isinstance(provider_copy.get("roles"), list)
            else str(provider_copy.get("roles", ""))
        ])

        provider_copy["searchable_text"] = (
            combined_text.lower()
        )

        normalized.append(provider_copy)

    return normalized


PROVIDER_DATABASE = load_provider_database()


# In[24]:


TOPIC_PROVIDER_KEYWORDS = {
    "exercise": [
        "exercise",
        "rehabilitation",
        "cardiac rehabilitation",
        "exercise physiology",
        "sports",
        "fitness",
        "cardiopulmonary exercise",
        "cardiology"
    ],
    "nutrition": [
        "nutrition",
        "dietitian",
        "diet",
        "feeding",
        "growth",
        "gastroenterology"
    ],
    "surgery": [
        "cardiac surgery",
        "cardiothoracic surgery",
        "congenital cardiac surgery",
        "surgeon",
        "surgery"
    ],
    "qol": [
        "psychology",
        "behavioral health",
        "neurodevelopment",
        "social work",
        "quality of life",
        "mental health"
    ],
    "caregiver": [
        "social work",
        "psychology",
        "behavioral health",
        "child life",
        "family support",
        "care coordination",
        "nursing"
    ],
    "education": [
        "congenital cardiology",
        "cardiology",
        "pediatric cardiology"
    ]
}


def diagnosis_keywords(diagnosis):

    mapping = {
        "Tetralogy of Fallot": [
            "tetralogy of fallot",
            "tof"
        ],
        "Fontan Circulation": [
            "fontan",
            "single ventricle"
        ],
        "Hypoplastic Left Heart Syndrome": [
            "hlhs",
            "hypoplastic left heart",
            "single ventricle"
        ],
        "Transposition of the Great Arteries": [
            "transposition",
            "tga",
            "arterial switch"
        ],
        "Atrioventricular Septal Defect": [
            "atrioventricular septal defect",
            "avsd",
            "av canal"
        ],
        "Coarctation of the Aorta": [
            "coarctation"
        ],
        "Ebstein Anomaly": [
            "ebstein"
        ]
    }

    return mapping.get(
        diagnosis,
        [diagnosis.lower()]
        if diagnosis != "Unknown"
        else []
    )


def recommend_providers(
    question,
    diagnosis,
    topic,
    hospital="Childrens National",
    top_n=3
):

    if not PROVIDER_DATABASE:
        return []

    topic_terms = TOPIC_PROVIDER_KEYWORDS.get(
        topic,
        []
    )

    condition_terms = diagnosis_keywords(
        diagnosis
    )

    question_words = {
        word
        for word in re.findall(
            r"[a-zA-Z]{5,}",
            question.lower()
        )
        if word not in {
            "about",
            "child",
            "daughter",
            "family",
            "should",
            "would",
            "could",
            "their",
            "there",
            "which"
        }
    }

    matches = []

    for provider in PROVIDER_DATABASE:

        provider_hospital = provider.get(
            "hospital",
            ""
        )

        if (
            hospital
            and provider_hospital
            and provider_hospital.lower()
            != hospital.lower()
        ):
            continue

        text = provider.get(
            "searchable_text",
            ""
        )

        score = 0
        reasons = []

        topic_hits = [
            term
            for term in topic_terms
            if term in text
        ]

        if topic_hits:
            score += min(
                50,
                15 + (10 * len(topic_hits))
            )

            reasons.append(
                "Profile matches the "
                f"{topic.replace('_', ' ')} care topic"
            )

        diagnosis_hits = [
            term
            for term in condition_terms
            if term in text
        ]

        if diagnosis_hits:
            score += min(
                35,
                20 + (5 * len(diagnosis_hits))
            )

            reasons.append(
                f"Profile mentions expertise relevant to {diagnosis}"
            )

        department = provider.get(
            "department",
            ""
        ).lower()

        if (
            topic == "surgery"
            and "surgery" in department
        ):
            score += 30
            reasons.append(
                "Member of the cardiac surgery department"
            )

        elif (
            topic in ["exercise", "education"]
            and "cardiology" in department
        ):
            score += 15
            reasons.append(
                "Member of the cardiology department"
            )

        shared_words = [
            word
            for word in question_words
            if word in text
        ]

        if shared_words:
            score += min(
                20,
                4 * len(shared_words)
            )

            reasons.append(
                "Provider profile shares relevant terms "
                "with the family question"
            )

        if provider.get("research_profile_url"):
            score += 3

        if score > 0:
            matches.append({
                "provider": provider,
                "score": score,
                "reasons": list(dict.fromkeys(reasons))
            })

    matches.sort(
        key=lambda item: (
            item["score"],
            item["provider"].get("name", "")
        ),
        reverse=True
    )

    return matches[:top_n]


def format_provider_matches(matches):

    if not matches:
        return """
No expertise-matched provider was identified from the current local
provider database. Please contact the congenital heart program for
appropriate care navigation.
""".strip()

    sections = []

    for index, match in enumerate(
        matches,
        start=1
    ):

        provider = match["provider"]
        reasons = match["reasons"]

        name = provider.get(
            "name",
            "Provider name unavailable"
        )

        specialty = (
            provider.get("specialty")
            or provider.get("department")
            or "Specialty not listed"
        )

        profile_url = provider.get(
            "profile_url",
            ""
        )

        reason_text = "\n".join(
            f"- {reason}"
            for reason in reasons
        )

        section = f"""
### {index}. {name}

**Specialty/Department:** {specialty}

**Prototype Match Score:** {match['score']}

**Why this provider matched:**

{reason_text}
""".strip()

        if profile_url:
            section += (
                f"\n\n**Official profile:** {profile_url}"
            )

        sections.append(section)

    return "\n\n---\n\n".join(sections)


# In[25]:

# ============================================================
# CHD FAMILY COPILOT V2
# Memory-aware, multi-agent, safety-first orchestration
# ============================================================

AGENT_NAMES = {
    "exercise": "Cardiac Exercise and Rehabilitation Agent",
    "nutrition": "Nutrition and Growth Agent",
    "surgery": "Congenital Cardiac Surgery Education Agent",
    "qol": "Quality-of-Life Agent",
    "caregiver": "Caregiver Support and Family Navigation Agent",
    "education": "Congenital Heart Disease Education Agent",
}

ALLOWED_TOPICS = set(AGENT_NAMES)
GUIDELINE_FILE = Path("guidelines.json")


# ============================================================
# CURATED GUIDELINES
# ============================================================

def load_guidelines(filename=GUIDELINE_FILE):
    """Load locally curated, human-reviewed guideline summaries."""
    path = Path(filename)
    if not path.exists():
        return []
    try:
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, list) else []
    except Exception:
        return []


GUIDELINE_DATABASE = load_guidelines()


def retrieve_guidelines(diagnosis, topics, max_results=3):
    if not GUIDELINE_DATABASE:
        return []

    query_terms = set()
    if diagnosis and diagnosis != "Unknown":
        query_terms.update(re.findall(r"[a-zA-Z]{4,}", diagnosis.lower()))
    query_terms.update(str(topic).lower() for topic in topics)

    scored = []
    for guideline in GUIDELINE_DATABASE:
        searchable = " ".join([
            str(guideline.get("title", "")),
            str(guideline.get("organization", "")),
            str(guideline.get("text", "")),
            " ".join(guideline.get("topics", [])),
        ]).lower()
        score = sum(1 for term in query_terms if term in searchable)
        if score > 0:
            scored.append((score, guideline))

    scored.sort(key=lambda item: item[0], reverse=True)
    return [item[1] for item in scored[:max_results]]


def format_guidelines(guidelines):
    if not guidelines:
        return "No locally curated guideline summary was available for this question."

    sections = []
    for guideline in guidelines:
        sections.append(f"""
Title: {guideline.get('title', 'Not listed')}
Organization: {guideline.get('organization', 'Not listed')}
Year: {guideline.get('year', 'Not listed')}
Reviewed Summary: {guideline.get('text', '')}
Source: {guideline.get('url', '')}
""".strip())
    return "\n\n---\n\n".join(sections)


# ============================================================
# CONVERSATION + LONGITUDINAL PATIENT MEMORY
# ============================================================

def conversation_text(history=None, max_messages=8):
    if not history:
        return "No previous conversation."

    recent = history[-max_messages:]
    return "\n".join(
        f"{message.get('role', 'unknown')}: {message.get('content', '')}"
        for message in recent
    )


def merge_patient_context(old_context, new_context):
    """Merge new facts into the longitudinal patient profile without erasing known facts."""
    merged = dict(old_context or {})

    for key, value in (new_context or {}).items():
        if value in [None, "", "Unknown", [], {}]:
            continue

        if key in {"symptoms", "procedures"}:
            previous = merged.get(key, [])
            if not isinstance(previous, list):
                previous = [previous]
            if not isinstance(value, list):
                value = [value]
            merged[key] = list(dict.fromkeys(previous + value))
        else:
            merged[key] = value

    merged["last_updated"] = datetime.now().isoformat(timespec="seconds")
    return merged


# ============================================================
# LLM CONTEXT EXTRACTOR
# ============================================================

def _strip_json_fence(text):
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def extract_context(question, history=None, patient_context=None):
    """Extract current-turn facts while resolving follow-ups from prior context."""
    system_prompt = """
You are a structured context extraction agent for a congenital heart disease family copilot.
Return VALID JSON ONLY. Never give medical advice and never invent patient facts.
Use previous patient context for follow-up language such as "she", "he", "what about swimming?",
"what about surgery?", or "who should we see?".

Return exactly this schema:
{
  "age": null,
  "sex": null,
  "diagnosis": "Unknown",
  "repair_status": null,
  "procedures": [],
  "activity": null,
  "symptoms": [],
  "topics": [],
  "caregiver_question": false
}

Allowed topics only: education, exercise, nutrition, surgery, qol, caregiver.
A question may have multiple topics.
Use "qol" for school, emotional, social, confidence, fatigue/daily-functioning concerns.
Use "caregiver" for parent/caregiver stress, coping, coordination, and family-navigation concerns.
"""

    user_prompt = f"""
PREVIOUS PATIENT CONTEXT:
{json.dumps(patient_context or {}, indent=2)}

RECENT CONVERSATION:
{conversation_text(history)}

CURRENT QUESTION:
{question}
"""

    try:
        raw = _strip_json_fence(ask_agent(system_prompt, user_prompt))
        result = json.loads(raw)
    except Exception:
        result = {
            "age": None,
            "sex": None,
            "diagnosis": identify_diagnosis(question),
            "repair_status": None,
            "procedures": [],
            "activity": identify_activity(question),
            "symptoms": [],
            "topics": [identify_topic(question)],
            "caregiver_question": identify_topic(question) == "caregiver",
        }

    topics = result.get("topics", []) or [identify_topic(question)]
    topics = [str(t).lower() for t in topics if str(t).lower() in ALLOWED_TOPICS]
    result["topics"] = list(dict.fromkeys(topics or ["education"]))
    return result


# ============================================================
# SAFETY AGENT
# ============================================================

def safety_agent(question, context=None):
    text = question.lower()

    emergency_terms = [
        "fainted", "fainting", "syncope", "passed out", "unresponsive",
        "cardiac arrest", "cannot breathe", "severe difficulty breathing",
        "blue lips", "turning blue", "cyanosis", "severe chest pain",
    ]
    urgent_terms = [
        "chest pain", "palpitations", "gets tired", "tires easily", "very tired",
        "fatigue during play", "shortness of breath", "exercise intolerance",
        "poor exercise tolerance", "dizziness", "cannot keep up",
    ]

    emergency_hits = [term for term in emergency_terms if term in text]
    urgent_hits = [term for term in urgent_terms if term in text]

    if emergency_hits:
        return {"level": "EMERGENCY", "triggers": emergency_hits, "human_review": True}
    if urgent_hits:
        return {"level": "URGENT", "triggers": urgent_hits, "human_review": True}
    return {"level": "ROUTINE", "triggers": [], "human_review": False}


# ============================================================
# MISSING INFORMATION DETECTOR
# ============================================================

TOPIC_REQUIRED_INFORMATION = {
    "exercise": ["age", "diagnosis", "activity"],
    "nutrition": ["age", "diagnosis"],
    "surgery": ["diagnosis"],
    "qol": ["age", "diagnosis"],
    "caregiver": ["diagnosis"],
    "education": ["diagnosis"],
}


def detect_missing_information(context):
    required = set()
    for topic in context.get("topics", ["education"]):
        required.update(TOPIC_REQUIRED_INFORMATION.get(topic, []))

    missing = []
    for field in required:
        if context.get(field) in [None, "", "Unknown", [], {}]:
            missing.append(field)
    return sorted(missing)


# ============================================================
# MULTI-AGENT COLLABORATION
# ============================================================

def run_specialized_agents(question, context, evidence, guideline_text, safety):
    diagnosis = context.get("diagnosis", "Unknown")
    activity = context.get("activity") or "General Activity"
    topics = context.get("topics", ["education"])

    risk_map = {"EMERGENCY": "HIGH", "URGENT": "MODERATE", "ROUTINE": "LOW"}
    risk = risk_map.get(safety.get("level"), "LOW")

    combined_evidence = f"""
PUBMED EVIDENCE
{evidence}

CURATED GUIDELINE MATERIAL
{guideline_text}
"""

    responses = {}
    for topic in topics:
        if topic == "exercise":
            responses["Exercise & Cardiac Rehabilitation"] = exercise_agent(
                question=question, diagnosis=diagnosis, activity=activity,
                risk=risk, evidence=combined_evidence
            )
        elif topic == "nutrition":
            responses["Nutrition & Growth"] = nutrition_agent(
                question=question, diagnosis=diagnosis, evidence=combined_evidence
            )
        elif topic == "surgery":
            responses["Cardiac Surgery"] = surgery_agent(
                question=question, diagnosis=diagnosis, evidence=combined_evidence
            )
        elif topic == "qol":
            responses["Quality of Life"] = qol_agent(
                question=question, diagnosis=diagnosis, evidence=combined_evidence
            )
        elif topic == "caregiver":
            responses["Caregiver Support"] = caregiver_agent(
                question=question, diagnosis=diagnosis, evidence=combined_evidence
            )
        else:
            responses["CHD Education"] = education_agent(
                question=question, diagnosis=diagnosis, evidence=combined_evidence
            )

    return responses


def synthesize_agent_responses(question, context, agent_responses, missing_information, safety):
    combined = "\n\n".join(
        f"===== {name} =====\n{response}"
        for name, response in agent_responses.items()
    )

    system_prompt = """
You are the response composer for a congenital heart disease family copilot.
Combine specialist-agent outputs into ONE concise, family-friendly response.

Rules:
- Remove duplication.
- Do not invent clinical facts.
- Do not diagnose, prescribe treatment, provide sports clearance, or make surgical decisions.
- Put urgent safety guidance before routine education when relevant.
- If information is missing, state what would help the care team.
- Do not claim a guideline recommendation unless supplied guideline material supports it.
- Use evidence conservatively.

Return exactly these sections:
# What I Would Do Next
# What This May Mean
# Key Considerations
# Information That Would Help Your Care Team
# Questions to Ask
# Evidence Summary
# Safety
"""

    user_prompt = f"""
QUESTION:
{question}

PATIENT CONTEXT:
{json.dumps(context, indent=2)}

SAFETY ASSESSMENT:
{json.dumps(safety, indent=2)}

MISSING INFORMATION:
{json.dumps(missing_information)}

SPECIALIST AGENT REPORTS:
{combined}
"""
    return ask_agent(system_prompt, user_prompt)


# ============================================================
# HALLUCINATION / EVIDENCE VERIFIER
# ============================================================

def hallucination_verifier(answer, evidence, guideline_text):
    system_prompt = """
You are an evidence-verification agent.
Compare the proposed answer only against the supplied PubMed material and curated guideline material.
Return VALID JSON ONLY using this schema:
{
  "status": "PASS",
  "unsupported_claims": [],
  "citation_concerns": [],
  "overall_evidence_support": "HIGH"
}
status must be PASS or REVIEW.
overall_evidence_support must be HIGH, MODERATE, or LOW.
Mark REVIEW when clinically important factual claims are not reasonably supported by the supplied material.
Do not reveal chain-of-thought.
"""

    user_prompt = f"""
ANSWER:
{answer}

PUBMED MATERIAL:
{evidence}

GUIDELINE MATERIAL:
{guideline_text}
"""

    try:
        raw = _strip_json_fence(ask_agent(system_prompt, user_prompt))
        result = json.loads(raw)
        if result.get("status") not in {"PASS", "REVIEW"}:
            raise ValueError("Invalid verification status")
        if result.get("overall_evidence_support") not in {"HIGH", "MODERATE", "LOW"}:
            result["overall_evidence_support"] = "LOW"
        return result
    except Exception:
        return {
            "status": "REVIEW",
            "unsupported_claims": [],
            "citation_concerns": ["Verification output could not be parsed."],
            "overall_evidence_support": "LOW",
        }


# ============================================================
# EXPLAINABLE PROVIDER MATCHING + GOVERNANCE
# ============================================================

def provider_confidence(score):
    if score >= 80:
        return "High"
    if score >= 55:
        return "Moderate"
    return "Exploratory"


def format_provider_matches_v2(matches):
    if not matches:
        return "No expertise-matched provider was identified from the current provider directory."

    sections = []
    for index, match in enumerate(matches, start=1):
        provider = match["provider"]
        reasons = match["reasons"]
        score = match["score"]
        name = provider.get("name", "Provider")
        specialty = provider.get("specialty") or provider.get("department") or "Specialty not listed"
        url = provider.get("profile_url", "")
        reason_text = "\n".join(f"- {reason}" for reason in reasons)

        block = f"""
### {index}. {name}

**Specialty/Department:** {specialty}

**Match confidence:** {provider_confidence(score)}

**Why this clinician may be relevant:**

{reason_text}
""".strip()
        if url:
            block += f"\n\n**Official profile:** {url}"
        sections.append(block)

    return "\n\n---\n\n".join(sections)


def build_governance_data(safety, missing_information, verifier, pubmed_count, guideline_count):
    return {
        "safety_level": safety.get("level", "ROUTINE"),
        "human_review_recommended": (
            bool(safety.get("human_review")) or verifier.get("status") == "REVIEW"
        ),
        "missing_information": missing_information,
        "pubmed_records_retrieved": pubmed_count,
        "guidelines_retrieved": guideline_count,
        "verification_status": verifier.get("status", "REVIEW"),
        "evidence_support": verifier.get("overall_evidence_support", "LOW"),
    }


# ============================================================
# CHIEF AGENT V2
# ============================================================

def chief_agent(
    question,
    hospital="Childrens National",
    history=None,
    patient_context=None,
    return_details=False,
):
    if not question or not question.strip():
        raise ValueError("Please enter a family question.")

    # 1. Context + longitudinal memory
    extracted = extract_context(question, history=history, patient_context=patient_context)
    updated_context = merge_patient_context(patient_context, extracted)

    if isinstance(patient_context, dict):
        patient_context.clear()
        patient_context.update(updated_context)

    diagnosis = updated_context.get("diagnosis", "Unknown")
    topics = updated_context.get("topics", ["education"])

    # 2. Safety + missing data
    safety = safety_agent(question, updated_context)
    missing_information = detect_missing_information(updated_context)

    # 3. PubMed retrieval across all active topics
    all_articles = []
    for topic in topics:
        try:
            all_articles.extend(evidence_agent.search(diagnosis=diagnosis, topic=topic))
        except Exception:
            pass

    article_map = {}
    for article in all_articles:
        pmid = article.get("PMID", "")
        article_map[pmid or str(id(article))] = article
    all_articles = list(article_map.values())
    evidence = summarize_evidence(all_articles)

    # 4. Curated guidelines
    guidelines = retrieve_guidelines(diagnosis=diagnosis, topics=topics)
    guideline_text = format_guidelines(guidelines)

    # 5. Multi-agent collaboration
    agent_responses = run_specialized_agents(
        question=question,
        context=updated_context,
        evidence=evidence,
        guideline_text=guideline_text,
        safety=safety,
    )

    # 6. Synthesize one family-facing response
    report = synthesize_agent_responses(
        question=question,
        context=updated_context,
        agent_responses=agent_responses,
        missing_information=missing_information,
        safety=safety,
    )

    # 7. Explainable provider matching across active topics
    provider_candidates = []
    for topic in topics:
        provider_candidates.extend(recommend_providers(
            question=question,
            diagnosis=diagnosis,
            topic=topic,
            hospital=hospital,
            top_n=3,
        ))

    provider_map = {}
    for match in provider_candidates:
        name = match["provider"].get("name", "")
        if not name:
            continue
        if name not in provider_map or match["score"] > provider_map[name]["score"]:
            provider_map[name] = match

    provider_matches = sorted(
        provider_map.values(), key=lambda item: item["score"], reverse=True
    )[:3]
    provider_report = format_provider_matches_v2(provider_matches)

    # 8. Evidence verification
    verification = hallucination_verifier(
        answer=report,
        evidence=evidence,
        guideline_text=guideline_text,
    )

    # 9. Governance metadata
    governance = build_governance_data(
        safety=safety,
        missing_information=missing_information,
        verifier=verification,
        pubmed_count=len(all_articles),
        guideline_count=len(guidelines),
    )

    active_agents = ", ".join(agent_responses.keys())
    patient_summary = f"""
# CHD Family Copilot Assessment

**Diagnosis:** {diagnosis}

**Active topic(s):** {", ".join(topics)}

**Activity:** {updated_context.get("activity") or "Not provided"}

**Safety classification:** {safety["level"]}

**Specialized agents consulted:** {active_agents}

**Hospital directory:** {hospital}
""".strip()

    governance_report = f"""
# 🛡️ AI Governance Dashboard

**Safety:** {governance["safety_level"]}

**Evidence support:** {governance["evidence_support"]}

**Verification:** {governance["verification_status"]}

**Human review recommended:** {"Yes" if governance["human_review_recommended"] else "No"}

**PubMed records retrieved:** {governance["pubmed_records_retrieved"]}

**Curated guidelines retrieved:** {governance["guidelines_retrieved"]}

**Missing information:** {", ".join(missing_information) if missing_information else "None identified"}
""".strip()

    final_report = f"""
{patient_summary}

---

{report}

---

# 👩‍⚕️ Expertise-Matched Specialists

These matches use publicly available provider-profile information. They are care-navigation
suggestions and do not rank physician quality.

{provider_report}

---

{governance_report}

---

# Important Safety Notice

This prototype provides educational and care-navigation support only. It does not diagnose,
prescribe treatment, provide sports clearance, determine whether surgery is needed, or replace
the treating congenital heart team.

For severe symptoms, fainting, significant breathing difficulty, persistent chest pain, blue
coloration, unresponsiveness, or another medical emergency, seek immediate medical care.
""".strip()

    if return_details:
        return {
            "report": final_report,
            "patient_context": updated_context,
            "topics": topics,
            "safety": safety,
            "missing_information": missing_information,
            "providers": provider_matches,
            "evidence": evidence,
            "guidelines": guideline_text,
            "verification": verification,
            "governance": governance,
        }

    return final_report
