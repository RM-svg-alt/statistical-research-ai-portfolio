# Statistical Research and CHD Family Copilot

## CHD Family Copilot

Python research prototype for congenital heart disease education and care navigation. The source implements intent recognition, risk screening, contextual information extraction, PubMed retrieval, topic-specific agents, response synthesis, and evidence-verification workflows.

**Source files:** `chd-family-copilot/chd_copilot(1).py` (expanded version), `chd_copilot.py`, and `chd_copilot_v2.py` (earlier versions).

**Requirements:** Python, `biopython`, `litellm`, an `OPENAI_API_KEY` environment variable for LLM-based responses, and a valid `NCBI_EMAIL` for PubMed access. Optional provider and guideline JSON data files are not included. This is a research prototype, not a medical device. Clinical behavior and end-to-end operation have not been validated as part of this package.

## Statistical programming

`statistical-analysis/UVA_original_extracted.txt` contains the original code and descriptive sections extracted from a SAS interview sample. `translation_analysis.R` and `translation_analysis.py` are earlier translation drafts; their equivalence to the SAS analysis has not been established. The source dataset is not included.

## Verification

The three Python source files were syntax-compiled successfully. Syntax compilation is not an end-to-end execution test.

## Publication review

Review all source files for employer ownership, institutional identifiers, credentials, and other non-public material before publishing to a public repository.
