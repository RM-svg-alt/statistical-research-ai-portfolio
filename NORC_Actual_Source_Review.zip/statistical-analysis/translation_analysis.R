# R translation of R. Mehta's eight-section SAS clinical registry sample.
# Usage: Rscript analysis.R registry_puf.csv output_dir
# Packages: dplyr, tidyr, ggplot2, splines, broom
suppressPackageStartupMessages({library(dplyr);library(tidyr);library(ggplot2);library(splines);library(broom)})
args <- commandArgs(trailingOnly=TRUE)
if(length(args)!=2) stop('Usage: Rscript analysis.R registry_puf.csv output_dir')
out <- args[2]; dir.create(out, recursive=TRUE, showWarnings=FALSE)
write_out <- function(x, filename) write.csv(x, file.path(out,filename),row.names=FALSE,na='')
raw <- read.csv(args[1], check.names=FALSE)

# 1. Cohort creation (same procedure mapping, inclusion, derivations as SAS)
proc_map <- list('VSD'=c(110,5001),'TOF repair'=c(350,360,370,3330,3340,5004),
 'AVC (AVSD) repair'=170,'Arterial switch operation'=1110,
 'Arterial switch operation (ASO) and VSD repair'=1120,
 'Glenn'=c(1670,1680,1690,1700,2130),'Fontan'=c(970,980,1000,1010,2780,2790,3310,3320),
 'Truncus'=230,'Norwood'=870,'Coarctation repair'=c(1210,1220,1230,1240,1250,1280,3460,3470))
lookup <- unlist(lapply(names(proc_map),function(n) setNames(rep(n,length(proc_map[[n]])),as.character(proc_map[[n]]))))
d <- raw %>% filter(IndexProc==1)
sy <- grep('^SY_',names(d),value=TRUE)
d$syndrome_ <- if(length(sy)) as.integer(rowSums(d[,sy,drop=FALSE]==1,na.rm=TRUE)>0) else 0L
d$procedure_desc <- unname(lookup[as.character(d$primproc)])
d <- d %>% filter(!is.na(procedure_desc), !procedure_desc %in% c('Glenn','Fontan')) %>%
 mutate(CPBTm_log=ifelse(CPBTm>0,log(CPBTm),NA_real_),
 XClampTm_log=ifelse(XClampTm>0,log(XClampTm),NA_real_),
 WeightKg_log=ifelse(WeightKg>0,log(WeightKg),NA_real_),
 BirthWtKg_log=ifelse(BirthWtKg>0,log(BirthWtKg),NA_real_),
 weight_category=cut(BirthWtKg,breaks=c(0,1,2,3,4,5,Inf),right=FALSE,
 labels=c('0-1 kg','1-2 kg','2-3 kg','3-4 kg','4-5 kg','>5 kg')),
 neonate=ifelse(is.na(AgeDays),NA_integer_,as.integer(AgeDays<=28)),
 low_birth_weight=ifelse(is.na(BirthWtKg),NA_integer_,as.integer(BirthWtKg<2.5)),
 TLOS=LOS+AgeDays) %>% filter(!is.na(weight_category),weight_category!='>5 kg')
write_out(d,'cohort.csv')

# 2. Clinical descriptive queries
nor <- d %>% filter(procedure_desc=='Norwood') %>% mutate(doubled_lt3mo=BirthWtKg>0 & WeightKg>0 & AgeDays<=90 & WeightKg>=2*BirthWtKg)
write_out(nor %>% filter(!is.na(doubled_lt3mo),doubled_lt3mo),'norwood_doubled.csv')
small <- d %>% filter(BirthWtKg>0,BirthWtKg<1)
write_out(data.frame(norwood_total=nrow(nor),norwood_doubled_lt3mo=sum(nor$doubled_lt3mo,na.rm=TRUE),
 pct_doubled_lt3mo=if(nrow(nor)) 100*mean(nor$doubled_lt3mo,na.rm=TRUE) else NA,
 N_lt1kg=nrow(small),Deaths_lt1kg=sum(small$MTopd==1,na.rm=TRUE),
 MortalityPct=if(nrow(small)) 100*mean(small$MTopd==1,na.rm=TRUE) else NA),'clinical_queries.csv')

# 3. Table 1 (the SAS macros show summary/test logic but do not assemble final tables)
cont <- intersect(c('BirthWtKg','GestAgeWeeks','AgeDays','WeightKg','Heightcm','CPBTm','XClampTm','Readmit30','LOS','PLOS'),names(d))
catvars <- intersect(c('Gender','Premature','AntenatalDiag','syndrome_','OpType','ReOpInAdm','AgeCat','Emergency','MTopd'),names(d))
table1 <- bind_rows(lapply(cont,function(v) d %>% group_by(weight_category) %>% summarise(n=sum(!is.na(.data[[v]])),
 median=median(.data[[v]],na.rm=TRUE),p25=as.numeric(quantile(.data[[v]],.25,na.rm=TRUE)),
 p75=as.numeric(quantile(.data[[v]],.75,na.rm=TRUE)),.groups='drop') %>% mutate(variable=v)))
write_out(table1,'table1_continuous.csv')
pvals <- bind_rows(lapply(cont,function(v) {
 z <- d %>% select(weight_category,all_of(v)) %>% drop_na()
 p <- tryCatch(kruskal.test(z[[v]]~z$weight_category)$p.value,error=function(e) NA_real_)
 data.frame(variable=v,test='Kruskal-Wallis',p=p)
}),lapply(catvars,function(v){tab<-table(d$weight_category,d[[v]],useNA='no');
 p<-tryCatch(suppressWarnings(chisq.test(tab)$p.value),error=function(e) NA_real_)
 data.frame(variable=v,test='Pearson chi-square',p=p)}))
write_out(pvals,'table1_tests.csv')

# 4. Multivariable models: SAS reference MTopd=2 interpreted as mortality=1.
# SAS stepwise selection is not replicated because selection criteria are unspecified.
# GLIMMIX has no RANDOM effect in supplied code; use fixed-effects binomial GLM.
model <- function(exposure,covars,filename) {
 vars <- c('MTopd',exposure,covars)
 if(!all(vars %in% names(d))) return(invisible(NULL))
 x <- d %>% filter(Premature!=3) %>% select(all_of(vars)) %>% drop_na()
 x$death <- as.integer(x$MTopd==1)
 if(length(unique(x$death))<2) return(invisible(NULL))
 categorical <- c('low_birth_weight','weight_category','syndrome_','OpType','AgeCat','Premature')
 terms <- vapply(c(exposure,covars),function(v) if(v %in% categorical) paste0('factor(',v,')') else v,character(1))
 f <- as.formula(paste('death ~',paste(terms,collapse=' + ')))
 fit <- tryCatch(glm(f,data=x,family=binomial()),error=function(e) NULL)
 if(!is.null(fit)) write_out(broom::tidy(fit) %>% mutate(OR=exp(estimate),lower95=exp(estimate-1.96*std.error),
 upper95=exp(estimate+1.96*std.error)) ,filename)
}
model('low_birth_weight',c('syndrome_','OpType','WeightKg','CPBTm_log','XClampTm_log','AgeCat','Premature'),'model_low_birth_weight.csv')
model('BirthWtKg',c('syndrome_','OpType','WeightKg','CPBTm_log','XClampTm_log','AgeCat','Premature'),'model_birth_weight.csv')
model('weight_category',c('CPBTm_log','XClampTm_log','AgeCat','Premature','syndrome_'),'model_weight_category.csv')

# 5. Temporal trends
counts <- d %>% filter(between(WeightKg,1.5,2)) %>% count(procedure_desc,SurgYear,name='count')
write_out(counts,'procedure_counts.csv')
change <- counts %>% arrange(procedure_desc,SurgYear) %>% group_by(procedure_desc) %>%
 summarise(first_year=first(SurgYear),last_year=last(SurgYear),first_count=first(count),
 last_count=last(count),increase_pct=100*(last_count/first_count-1),.groups='drop')
write_out(change,'procedure_increase.csv')
prem <- d %>% group_by(SurgYear) %>% summarise(proportion_percent=100*mean(Premature==1,na.rm=TRUE),.groups='drop')
write_out(prem,'premature_by_year.csv')

# 6. Clinical visualizations
agg <- d %>% group_by(procedure_desc,WeightKg_log) %>% summarise(total_deaths=sum(MTopd==1,na.rm=TRUE),
 total_count=n(),death_percentage=100*total_deaths/total_count,.groups='drop')
p <- ggplot(agg,aes(WeightKg_log,death_percentage))+geom_point()+facet_wrap(~procedure_desc,scales='free_x')+
 labs(x='Log operative weight (kg)',y='Mortality (%)')+theme_bw()
ggsave(file.path(out,'mortality_by_procedure.png'),p,width=11,height=8)
p <- ggplot(d,aes(x=factor(MTopd),y=AgeDays,fill=procedure_desc))+geom_boxplot()+
 labs(x='Mortality status',y='Age at surgery (days)')+theme_bw()
ggsave(file.path(out,'age_by_mortality.png'),p,width=10,height=6)

# 7. Nonlinear age-mortality association (binomial spline)
co <- d %>% filter(procedure_desc=='Coarctation repair',AgeDays<=30) %>% select(AgeDays,MTopd) %>% drop_na()
if(nrow(co)>=12 && length(unique(co$MTopd))>1) {
 co$death <- as.integer(co$MTopd==1)
 fit <- tryCatch(glm(death~ns(AgeDays,df=4),data=co,family=binomial()),error=function(e) NULL)
 if(!is.null(fit)) {grid<-data.frame(AgeDays=seq(min(co$AgeDays),max(co$AgeDays),length.out=100));
 grid$predicted_mortality<-predict(fit,newdata=grid,type='response');write_out(grid,'coarctation_spline.csv')}
}
nor <- d %>% filter(procedure_desc=='Norwood') %>% mutate(death=as.integer(MTopd==1))
if(nrow(nor)>3) {
 p<-ggplot(nor,aes(AgeDays,death))+geom_jitter(height=.05,alpha=.2)+geom_smooth(method='loess',se=TRUE)+
 labs(x='Age at surgery (days)',y='Mortality indicator')+theme_bw()
 ggsave(file.path(out,'norwood_age_mortality.png'),p,width=8,height=5)
}

# 8. Hospital-volume aggregation and patient-level join
h <- d %>% group_by(STS_HospID) %>% summarise(Total_Procedures=n(),Years=n_distinct(SurgYear),.groups='drop') %>%
 mutate(Avg_Annual_Volume=Total_Procedures/Years,VolumeGroup=ifelse(Avg_Annual_Volume>=48,'High','Low'))
write_out(h,'hospital_volume.csv')
final <- d %>% left_join(h %>% select(STS_HospID,Avg_Annual_Volume,VolumeGroup),by='STS_HospID')
stopifnot(nrow(final)==nrow(d))
write_out(final,'final_data.csv')
message('Outputs saved in ',out)
