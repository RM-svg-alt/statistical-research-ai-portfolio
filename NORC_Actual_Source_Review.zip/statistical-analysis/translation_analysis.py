"""Python translation of R. Mehta's eight-section SAS registry sample.
Usage: python analysis.py path/to/registry_puf.csv output_dir
Dependencies: pandas numpy scipy statsmodels matplotlib patsy
Input is user-provided; no clinical data are distributed.
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, kruskal
import statsmodels.formula.api as smf
import statsmodels.api as sm
from patsy import bs
import matplotlib.pyplot as plt

PROCEDURES = {
    'VSD': [110, 5001], 'TOF repair': [350,360,370,3330,3340,5004],
    'AVC (AVSD) repair': [170], 'Arterial switch operation': [1110],
    'Arterial switch operation (ASO) and VSD repair': [1120],
    'Glenn': [1670,1680,1690,1700,2130],
    'Fontan': [970,980,1000,1010,2780,2790,3310,3320],
    'Truncus': [230], 'Norwood': [870],
    'Coarctation repair': [1210,1220,1230,1240,1250,1280,3460,3470],
}
CAT = ['Gender','Premature','AntenatalDiag','syndrome_','OpType','ReOpInAdm','AgeCat','Emergency','MTopd']
CONT = ['BirthWtKg','GestAgeWeeks','AgeDays','WeightKg','Heightcm','CPBTm','XClampTm','Readmit30','LOS','PLOS']

def prepare(df):
    d = df.loc[df['IndexProc'].eq(1)].copy()
    syndrome_cols = [c for c in d if c.startswith('SY_')]
    d['syndrome_'] = d[syndrome_cols].eq(1).any(axis=1).astype(int) if syndrome_cols else 0
    lookup = {code: label for label, codes in PROCEDURES.items() for code in codes}
    d['procedure_desc'] = d['primproc'].map(lookup)
    d = d.loc[d['procedure_desc'].notna() & ~d['procedure_desc'].isin(['Glenn','Fontan'])].copy()
    for col in ['CPBTm','XClampTm','WeightKg','BirthWtKg']:
        d[col + '_log'] = np.log(d[col].where(d[col] > 0))
    d['weight_category'] = pd.cut(d['BirthWtKg'], bins=[0,1,2,3,4,5,np.inf],
        right=False, labels=['0-1 kg','1-2 kg','2-3 kg','3-4 kg','4-5 kg','>5 kg'])
    d = d.loc[d['weight_category'].ne('>5 kg') & d['weight_category'].notna()].copy()
    d['neonate'] = np.where(d['AgeDays'].notna(), (d['AgeDays'] <= 28).astype(int), np.nan)
    d['low_birth_weight'] = np.where(d['BirthWtKg'].notna(), (d['BirthWtKg'] < 2.5).astype(int), np.nan)
    d['TLOS'] = d['LOS'] + d['AgeDays']
    return d

def descriptives(d):
    rows = []
    for var in CONT:
        if var not in d: continue
        for group, g in d.groupby('weight_category', observed=True):
            x = pd.to_numeric(g[var], errors='coerce').dropna()
            rows.append(dict(variable=var, group=str(group), n=len(x),
                median=x.median(), p25=x.quantile(.25), p75=x.quantile(.75)))
    cont = pd.DataFrame(rows)
    pvals = []
    for var in CONT:
        if var not in d: continue
        groups = [pd.to_numeric(g[var], errors='coerce').dropna().values for _,g in d.groupby('weight_category',observed=True)]
        groups = [x for x in groups if len(x)]
        pvals.append(dict(variable=var, test='Kruskal-Wallis', p=kruskal(*groups).pvalue if len(groups)>1 else np.nan))
    for var in CAT:
        if var not in d: continue
        tab = pd.crosstab(d['weight_category'], d[var])
        pvals.append(dict(variable=var, test='Pearson chi-square', p=chi2_contingency(tab)[1] if min(tab.shape)>1 else np.nan))
    return cont, pd.DataFrame(pvals)

def fit_logit(d, exposure, covars, outcome='MTopd'):
    """Model mortality=1 explicitly; original SAS PROC LOGISTIC uses reference outcome 2.
    GLIMMIX with no RANDOM statement is translated as fixed-effect binomial GLM.
    Stepwise selection is intentionally not reproduced: it needs a specified rule.
    """
    cols = [outcome, exposure] + covars
    x = d.loc[d['Premature'].ne(3), cols].dropna().copy()
    x['death'] = (x[outcome] == 1).astype(int)
    if x['death'].nunique() < 2: return pd.DataFrame()
    formula = 'death ~ ' + ' + '.join([f'C({v})' if v in ['syndrome_','OpType','AgeCat','Premature','weight_category','low_birth_weight'] else v for v in [exposure]+covars])
    model = smf.glm(formula, data=x, family=sm.families.Binomial()).fit()
    ci = model.conf_int()
    return pd.DataFrame({'term':model.params.index, 'OR':np.exp(model.params.values),
                         'lower95':np.exp(ci.iloc[:,0].values), 'upper95':np.exp(ci.iloc[:,1].values),
                         'p':model.pvalues.values})

def trends(d):
    w = d.loc[d['WeightKg'].between(1.5,2.0,inclusive='both')]
    counts = w.groupby(['procedure_desc','SurgYear']).size().rename('count').reset_index()
    changes = []
    for proc,g in counts.groupby('procedure_desc'):
        g=g.sort_values('SurgYear'); first,last=g.iloc[0],g.iloc[-1]
        changes.append(dict(procedure_desc=proc, first_year=first.SurgYear,last_year=last.SurgYear,
          first_count=first['count'],last_count=last['count'],
          increase_pct=(last['count']/first['count']-1)*100 if first['count'] else np.nan))
    prem = d.groupby('SurgYear')['Premature'].apply(lambda s: s.eq(1).mean()*100).rename('proportion_percent').reset_index()
    return counts, pd.DataFrame(changes), prem

def hospital_volume(d):
    h = d.groupby('STS_HospID').agg(Total_Procedures=('primproc','size'),Years=('SurgYear','nunique')).reset_index()
    h['Avg_Annual_Volume'] = h['Total_Procedures']/h['Years'].replace(0,np.nan)
    h['VolumeGroup'] = np.where(h['Avg_Annual_Volume']>=48,'High','Low')
    return h, d.merge(h[['STS_HospID','Avg_Annual_Volume','VolumeGroup']],on='STS_HospID',how='left',validate='many_to_one')

def figures(d, out):
    for proc,g in d.groupby('procedure_desc'):
        agg = g.groupby('WeightKg_log')['MTopd'].agg(n='size',deaths=lambda s:s.eq(1).sum()).reset_index()
        agg['death_percentage'] = 100*agg['deaths']/agg['n']
        if not agg.empty:
            fig,ax=plt.subplots();ax.scatter(agg['WeightKg_log'],agg['death_percentage'])
            ax.set(xlabel='Log operative weight (kg)',ylabel='Mortality (%)',title=proc)
            fig.savefig(out / ('mortality_'+proc.replace(' ','_').replace('/','_')+'.png'),bbox_inches='tight');plt.close(fig)
    subset=d.loc[d['procedure_desc'].eq('Norwood') & d['AgeDays'].notna() & d['MTopd'].notna()]
    if len(subset)>3:
        fig,ax=plt.subplots();ax.scatter(subset['AgeDays'],subset['MTopd'].eq(1).astype(int),alpha=.2)
        ax.set(xlabel='Age at surgery (days)',ylabel='Mortality indicator',title='Norwood mortality by age')
        fig.savefig(out/'norwood_age_mortality.png',bbox_inches='tight');plt.close(fig)

def spline_model(d):
    x=d.loc[d['procedure_desc'].eq('Coarctation repair') & d['AgeDays'].le(30), ['AgeDays','MTopd']].dropna().copy()
    if len(x)<12 or x['MTopd'].nunique()<2: return pd.DataFrame()
    x['death']=x['MTopd'].eq(1).astype(int)
    model=smf.glm('death ~ bs(AgeDays, df=4)',data=x,family=sm.families.Binomial()).fit()
    grid=pd.DataFrame({'AgeDays':np.linspace(x.AgeDays.min(),x.AgeDays.max(),100)})
    grid['predicted_mortality']=model.predict(grid)
    return grid

def run(path, output):
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    d=prepare(pd.read_csv(path));d.to_csv(out/'cohort.csv',index=False)
    nor=d.loc[d.procedure_desc.eq('Norwood')].copy()
    nor['doubled_lt3mo']=(nor.BirthWtKg.gt(0)&nor.WeightKg.gt(0)&nor.AgeDays.le(90)&nor.WeightKg.ge(2*nor.BirthWtKg))
    nor.loc[nor.doubled_lt3mo].to_csv(out/'norwood_doubled.csv',index=False)
    small=d.loc[d.BirthWtKg.gt(0)&d.BirthWtKg.lt(1)]
    pd.DataFrame([{'norwood_total':len(nor),'norwood_doubled_lt3mo':nor.doubled_lt3mo.sum(),
        'pct_doubled_lt3mo':100*nor.doubled_lt3mo.mean() if len(nor) else np.nan,
        'N_lt1kg':len(small),'Deaths_lt1kg':small.MTopd.eq(1).sum(),
        'MortalityPct':100*small.MTopd.eq(1).mean() if len(small) else np.nan}]).to_csv(out/'clinical_queries.csv',index=False)
    desc,p=descriptives(d);desc.to_csv(out/'table1_continuous.csv',index=False);p.to_csv(out/'table1_tests.csv',index=False)
    for name,exposure,covs in [('low_birth_weight','low_birth_weight',['syndrome_','OpType','WeightKg','CPBTm_log','XClampTm_log','AgeCat','Premature']),
        ('birth_weight','BirthWtKg',['syndrome_','OpType','WeightKg','CPBTm_log','XClampTm_log','AgeCat','Premature']),
        ('weight_category','weight_category',['CPBTm_log','XClampTm_log','AgeCat','Premature','syndrome_'])]:
        try: fit_logit(d,exposure,covs).to_csv(out/f'model_{name}.csv',index=False)
        except (ValueError,np.linalg.LinAlgError) as e: print(f'{name} model unavailable: {e}')
    for name,t in zip(['procedure_counts','procedure_increase','premature_by_year'],trends(d)): t.to_csv(out/f'{name}.csv',index=False)
    h,final=hospital_volume(d);h.to_csv(out/'hospital_volume.csv',index=False);final.to_csv(out/'final_data.csv',index=False)
    spline_model(d).to_csv(out/'coarctation_spline.csv',index=False)
    figures(d,out)
    print('Saved outputs to',out)

if __name__=='__main__':
    if len(sys.argv)!=3: raise SystemExit('Usage: python analysis.py registry_puf.csv output_dir')
    run(sys.argv[1],sys.argv[2])
